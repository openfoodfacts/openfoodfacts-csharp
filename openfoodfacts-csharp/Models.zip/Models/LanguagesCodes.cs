
namespace OpenFoodFactsCSharp.model
{
    public class LanguagesCodes
    {
        public string? En { get; set; }

        public string? Fr { get; set; }

        public string? Pl { get; set; }
    }
}
