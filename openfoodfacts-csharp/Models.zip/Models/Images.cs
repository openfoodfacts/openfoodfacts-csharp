
using System.Collections.Generic;

namespace OpenFoodFactsCSharp.model
{
    public class Images
    {
        // To capture any unexpected properties
        public Dictionary<string, object> Other { get; set; } = new Dictionary<string, object>();
    }
}
