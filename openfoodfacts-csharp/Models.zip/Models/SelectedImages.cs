
namespace OpenFoodFactsCSharp.model
{
    public class SelectedImages
    {
        public SelectedImage? Front { get; set; }

        public SelectedImage? Ingredients { get; set; }

        public SelectedImage? Nutrition { get; set; }
    }
}
